# ProjetoP2_ListaPraMim
Projeto em grupo de Laboratório de Programação 2

Alunos:

* Henry Maldiney de Lira Nóbrega Filho - 117210389
* Igor Santa Ritta Seabra - 117210304
* Wesley Roseno Saraiva - 117210715